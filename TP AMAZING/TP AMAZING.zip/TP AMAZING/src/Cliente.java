public class Cliente {
    private String DNI;
    private String nombre;
    private String direccion;

    public Cliente(String DNI, String nombre, String direccion) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    // Getters y setters

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    //CREA CLIENTE
    public Cliente crearCliente(String DNI, String nombre, String direccion) {
        if (DNI == null || DNI.isEmpty() || nombre == null || nombre.isEmpty() || direccion == null || direccion.isEmpty()) {
            throw new IllegalArgumentException("Los datos del cliente no pueden ser nulos o vacíos.");
        }

        return new Cliente(DNI, nombre, direccion);
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "DNI='" + DNI + '\'' +
                ", nombre='" + nombre + '\'' +
                ", direccion='" + direccion + '\'' +
                '}';
    }
}
